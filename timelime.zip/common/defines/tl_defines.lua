--Changed END_DATE variable from 1821.1.2 to 9999.12.31

NDefines.NGame.END_DATE = "9999.12.31"